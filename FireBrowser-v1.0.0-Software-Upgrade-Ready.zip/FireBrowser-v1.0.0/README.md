# FireBrowser

Fire TV browser baseline for Fire TV Stick 4K 2nd Gen / Fire OS 8.

## Software upgrade design

Keep these constant forever:
- `applicationId = com.akshayaro.firebrowser`
- the same release signing key

For each future release:
1. increase `versionCode`
2. change `versionName`
3. build and host the new APK
4. update `update/latest.json`

The installed app can then use the **Update** button to download and install the new APK over the existing FireBrowser.

## Initial installation

Build the release APK with GitHub Actions, host the APK at a direct HTTPS URL, and enter that URL in Downloader on Fire TV.

## Important

Never lose the release signing key. Android will not install a future APK as an upgrade unless it is signed with the same key.
