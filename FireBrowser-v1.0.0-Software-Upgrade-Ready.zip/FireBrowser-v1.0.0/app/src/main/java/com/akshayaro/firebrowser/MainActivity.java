package com.akshayaro.firebrowser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private EditText addressBar;
    private ProgressBar progress;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private static final String HOME = "https://duckduckgo.com/";
    private final Set<String> blockedHosts = new HashSet<>(Arrays.asList(
            "doubleclick.net","googlesyndication.com","googleadservices.com",
            "adservice.google.com","adsystem.com","scorecardresearch.com",
            "taboola.com","outbrain.com"
    ));

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        addressBar = findViewById(R.id.addressBar);
        progress = findViewById(R.id.progress);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUserAgentString(s.getUserAgentString() + " FireBrowser/1.0");

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return false;
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                String host = req.getUrl().getHost();
                if (host != null) {
                    String h = host.toLowerCase();
                    for (String blocked : blockedHosts) {
                        if (h.equals(blocked) || h.endsWith("." + blocked)) {
                            return new WebResourceResponse("text/plain", "utf-8",
                                    new ByteArrayInputStream(new byte[0]));
                        }
                    }
                }
                return super.shouldInterceptRequest(view, req);
            }
            @Override
            public void onPageStarted(WebView view, String url, Bitmap icon) {
                addressBar.setText(url);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                addressBar.setText(url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                setContentView(view);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                customView = null;
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                setContentView(R.layout.activity_main);
                recreate();
            }
        });

        findViewById(R.id.backBtn).setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
        });
        findViewById(R.id.forwardBtn).setOnClickListener(v -> {
            if (webView.canGoForward()) webView.goForward();
        });
        findViewById(R.id.homeBtn).setOnClickListener(v -> webView.loadUrl(HOME));
        findViewById(R.id.reloadBtn).setOnClickListener(v -> webView.reload());
        findViewById(R.id.goBtn).setOnClickListener(v -> navigate());
        findViewById(R.id.updateBtn).setOnClickListener(v ->
                startActivity(new Intent(this, UpdateActivity.class)));

        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate();
                return true;
            }
            return false;
        });

        if (state == null) webView.loadUrl(HOME);
        else webView.restoreState(state);

        addressBar.requestFocus();
    }

    private void navigate() {
        String q = addressBar.getText().toString().trim();
        if (q.isEmpty()) return;
        if (!q.contains("://")) {
            if (q.contains(".") && !q.contains(" ")) q = "https://" + q;
            else q = "https://duckduckgo.com/?q=" + android.net.Uri.encode(q);
        }
        webView.loadUrl(q);
        webView.requestFocus();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        webView.saveState(out);
        super.onSaveInstanceState(out);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            recreate();
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.clearHistory();
            webView.clearCache(true);
        }
        super.onDestroy();
    }
}
