package com.akshayaro.firebrowser;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UpdateActivity extends AppCompatActivity {
    // Change this once you host latest.json.
    // Example: https://raw.githubusercontent.com/AkshayAro99/FireBrowser/main/update/latest.json
    private static final String UPDATE_JSON =
            "https://raw.githubusercontent.com/AkshayAro99/FireBrowser/main/update/latest.json";

    private TextView status;
    private ProgressBar progress;
    private Button installBtn;
    private File apkFile;
    private String apkUrl;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_update);
        status = findViewById(R.id.status);
        progress = findViewById(R.id.updateProgress);
        installBtn = findViewById(R.id.installBtn);

        findViewById(R.id.closeBtn).setOnClickListener(v -> finish());
        installBtn.setOnClickListener(v -> {
            if (apkFile == null || !apkFile.exists()) return;
            installApk();
        });

        check();
    }

    private void check() {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_JSON).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                JSONObject o = new JSONObject(sb.toString());
                int latestCode = o.getInt("versionCode");
                String latestName = o.getString("versionName");
                apkUrl = o.getString("apkUrl");

                int current = getPackageManager()
                        .getPackageInfo(getPackageName(), 0).versionCode;

                if (latestCode <= current) {
                    runOnUiThread(() -> {
                        status.setText("You already have the latest version.");
                        progress.setVisibility(View.GONE);
                    });
                } else {
                    runOnUiThread(() ->
                            status.setText("New version " + latestName + " found. Downloading…"));
                    download();
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("Update check failed. Try again later.");
                    progress.setVisibility(View.GONE);
                });
            }
        }).start();
    }

    private void download() throws Exception {
        File dir = new File(getCacheDir(), "updates");
        if (!dir.exists()) dir.mkdirs();
        apkFile = new File(dir, "FireBrowser-update.apk");

        HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
        int total = c.getContentLength();

        try (BufferedInputStream in = new BufferedInputStream(c.getInputStream());
             FileOutputStream out = new FileOutputStream(apkFile)) {
            byte[] buf = new byte[8192];
            int n, done = 0;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                int pct = total > 0 ? (done * 100 / total) : 0;
                runOnUiThread(() -> progress.setProgress(pct));
            }
        }

        runOnUiThread(() -> {
            status.setText("Update downloaded. Select Install Update.");
            installBtn.setVisibility(View.VISIBLE);
            installBtn.requestFocus();
        });
    }

    private void installApk() {
        if (android.os.Build.VERSION.SDK_INT >= 26 &&
                !getPackageManager().canRequestPackageInstalls()) {
            Intent perm = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName()));
            startActivity(perm);
            status.setText("Allow FireBrowser to install updates, then return and select Install Update again.");
            return;
        }

        Uri uri = FileProvider.getUriForFile(
                this, getPackageName() + ".files", apkFile);

        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }
}
